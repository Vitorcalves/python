"""
Exemplo dicionario - 1
"""

contato = {}

contato = {'nome': 'Beatriz', 'sexo': 'F', 'idade': 20}

print(f"{contato['nome']} tem {contato['idade']} ano(s)")

print("-" * 40)
print(f"KEYS: {contato.keys()}")
print(f"VALUES: {contato.values()}")
print(f"ITENS: {contato.items()}")